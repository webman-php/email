<?php

use plugin\admin\api\Middleware;

return [
    'admin' => [
        Middleware::class
    ]
];